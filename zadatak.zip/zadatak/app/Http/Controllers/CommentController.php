<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Auth;
use Illuminate\Support\Facades\Redirect;
use App\comment as comment;

class CommentController extends Controller
{
   public function showPage()
 {  
  $comments = DB::select('select * from comments');  
  return View::make('commentpage' , array('comments' => $comments));
 }
 
 public function storeComment()
 {
  $input = Input::all();
  /*
$validation = Validator::make($input, comment::$storevalid);

                if ($validation->passes())


        if (Auth::check())
*/

$validation = Validator::make($input, comment::$storevalid);

                if ($validation->passes() and Auth::check())
        {               
            $com = new comment();
     $com->comment_text = Input::get('commentText');
     date_default_timezone_set('Asia/Colombo');    
     $com->post_d_time = date('Y/m/d H:i:s');   
     $com->save();
   
     $validation = array('Successfully added the Comment!');
   
     return Redirect::back()
   ->withErrors($validation);            
        }
  return Redirect::back()
            ->withInput()
            ->withErrors($validation);
 }
}
