<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">  
 
</head>

<body>
<div>
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d89729.9399355496!2d14.3567762!3d45.3475885!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4764a12517aabe2d%3A0x373c6f383dcbb670!2sRijeka!5e0!3m2!1shr!2shr!4v1489916452812" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>





<div class="detailBox    <div class="titleBox">
      <label>Comments </label>        
    </div>
   
    <div class="actionBox">
        <ul class="commentList">             
          <?php if(!empty($comments)): ?>
          <?php
          $comments = array_reverse($comments);
          ?>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="commentAnswerBox" style="background-color:#ade5f4"></div>
              <li>               
                <div class="commentText">                    
                    <p class="" ><?php echo e($cm->comment_text); ?></p> 
                    <div style="margin-top:10px">                    
                      <span class="date sub-text" id="dt">on <?php echo e($cm->post_d_time); ?></span>                    
                    </div>
                </div>
              </li>              
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
          <?php endif; ?>
        </ul>      
    </div>

    <div class="actionBox">
        <?php echo e(Form::open(array('url'=>'/postcomment', 'method' => 'post' , 'class' => 'form-inline' ))); ?>        
          <div class="form-group" style="width:100%; position:relative">                             
              <?php echo e(Form::textarea('commentText', null, ['class' => 'form-control', 'placeholder' => 'Add your comment', 'rows' => '4'])); ?>

          </div>
          <div class="form-group">                
              <?php echo e(Form::submit('Post Comment', array('class' => 'btn btn-block btn-primary' , 'style' => 'width:220px'))); ?>

          </div>
        <?php echo e(Form::close()); ?>         
    </div>
</div>

<div class="valid">
  <?php if($errors->any()): ?>      
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-info">
        <strong>Alert!</strong> <?php echo e($message); ?>

      </div>  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
  <?php endif; ?>
</div>

</body>
</html>