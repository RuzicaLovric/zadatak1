<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">  
 
</head>

<body>
<div>
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d89729.9399355496!2d14.3567762!3d45.3475885!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4764a12517aabe2d%3A0x373c6f383dcbb670!2sRijeka!5e0!3m2!1shr!2shr!4v1489916452812" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>





<div class="detailBox    <div class="titleBox">
      <label>Comments </label>        
    </div>
   
    <div class="actionBox">
        <ul class="commentList">             
          @if (!empty($comments))
          <?php
          $comments = array_reverse($comments);
          ?>
            @foreach ($comments as $cm)
              <div class="commentAnswerBox" style="background-color:#ade5f4"></div>
              <li>               
                <div class="commentText">                    
                    <p class="" >{{$cm->comment_text}}</p> 
                    <div style="margin-top:10px">                    
                      <span class="date sub-text" id="dt">on {{$cm->post_d_time}}</span>                    
                    </div>
                </div>
              </li>              
            @endforeach  
          @endif
        </ul>      
    </div>

    <div class="actionBox">
        {{ Form::open(array('url'=>'/postcomment', 'method' => 'post' , 'class' => 'form-inline' )) }}        
          <div class="form-group" style="width:100%; position:relative">                             
              {{ Form::textarea('commentText', null, ['class' => 'form-control', 'placeholder' => 'Add your comment', 'rows' => '4']) }}
          </div>
          <div class="form-group">                
              {{ Form::submit('Post Comment', array('class' => 'btn btn-block btn-primary' , 'style' => 'width:220px')) }}
          </div>
        {{ Form::close() }}         
    </div>
</div>

<div class="valid">
  @if ($errors->any())      
    @foreach( $errors->all() as $message )
      <div class="alert alert-info">
        <strong>Alert!</strong> {{ $message }}
      </div>  
    @endforeach        
  @endif
</div>

</body>
</html>